import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.zoya.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.zoya.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
}

// हिंदी का ऑफ़लाइन आवाज़ मॉडल बिल्ड के समय अपने आप डाउनलोड होगा
tasks.register("fetchModel") {
    val out = file("src/main/assets/model-hi")
    doLast {
        if (!File(out, "uuid").exists()) {
            val zip = File(layout.buildDirectory.get().asFile, "model-hi.zip")
            zip.parentFile.mkdirs()
            URL("https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip").openStream().use { i ->
                zip.outputStream().use { o -> i.copyTo(o) }
            }
            out.deleteRecursively()
            project.copy {
                from(zipTree(zip))
                into(out)
                eachFile { relativePath = RelativePath(true, *relativePath.segments.drop(1).toTypedArray()) }
                includeEmptyDirs = false
            }
            File(out, "uuid").writeText(java.util.UUID.randomUUID().toString())
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("fetchModel") }
