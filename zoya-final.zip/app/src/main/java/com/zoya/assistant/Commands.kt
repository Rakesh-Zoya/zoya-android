package com.zoya.assistant

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import java.util.Calendar

object Commands {
    @Volatile var lastReply = ""
    private val ui = Handler(Looper.getMainLooper())

    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "यू ट्यूब" to "youtube", "यूटयूब" to "youtube", "यु ट्यूब" to "youtube",
        "व्हाट्सऐप" to "whatsapp", "व्हाट्सएप" to "whatsapp", "वाट्सएप" to "whatsapp",
        "वाट्सऐप" to "whatsapp", "व्हाट्स ऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "क्रोम" to "chrome", "कैमरा" to "camera", "सेटिंग" to "settings",
        "गैलरी" to "gallery", "फेसबुक" to "facebook", "इंस्टाग्राम" to "instagram",
        "फोन" to "phone", "फ़ोन" to "phone", "मैप्स" to "maps", "जीमेल" to "gmail",
        "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "मैसेज" to "messages", "गूगल" to "google"
    )
    private val clickAliases = mapOf("सेंड" to "send", "सर्च" to "search", "ओके" to "ok", "सबमिट" to "submit", "लाइक" to "like", "शेयर" to "share")
    private val openStop = setOf(
        "खोलो", "खोल", "दो", "करो", "को", "open", "ओपन", "start", "launch", "please",
        "जोया", "ज़ोया", "zoya", "चलाओ", "ऐप", "app", "में", "जाओ"
    )
    private val waWords = setOf(
        "whatsapp", "व्हाट्सएप", "वाट्सएप", "व्हाट्सऐप", "वाट्सऐप", "पर", "भेजो", "भेज",
        "दो", "मैसेज", "message", "लिखो", "कि", "करो"
    )
    private val numWords = mapOf(
        "एक" to 1, "दो" to 2, "तीन" to 3, "चार" to 4, "पाँच" to 5, "पांच" to 5, "छह" to 6, "छः" to 6,
        "छे" to 6, "सात" to 7, "आठ" to 8, "नौ" to 9, "दस" to 10, "ग्यारह" to 11, "बारह" to 12,
        "पंद्रह" to 15, "पन्द्रह" to 15, "बीस" to 20, "पच्चीस" to 25, "तीस" to 30, "चालीस" to 40,
        "पैंतालीस" to 45, "पचास" to 50, "साठ" to 60
    )
    private val months = listOf("जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर")

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun strip(t: String, stop: Set<String>) =
        t.split(" ").filter { it.isNotBlank() && it !in stop }.joinToString(" ")

    private fun toNum(s: String): Int? = s.toIntOrNull() ?: numWords[s]
    private fun numBefore(t: String, word: String): Int? {
        val tok = t.split(" ")
        val i = tok.indexOfFirst { it.contains(word) }
        return if (i > 0) toNum(tok[i - 1]) else null
    }

    private fun go(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {}
    }

    fun run(ctx: Context, said: String): String? {
        val t = said.lowercase().trim().trimEnd('.', '।', '?', '!')
        val svc = ZoyaAccessibilityService.instance
        val noCtl = "फ़ोन कंट्रोल चालू नहीं है। पहले उसे चालू कीजिए।"
        fun global(action: Int, ok: String): String =
            if (svc == null) noCtl else { svc.performGlobalAction(action); ok }

        val toks = t.split(" ")
        return when {
            // ---- याददाश्त ----
            has(t, "याद रखो", "याद रखना", "remember") -> {
                Memory.add(ctx, said); "ठीक है, याद रख लिया।"
            }
            has(t, "क्या याद है", "याददाश्त क्या", "what do you remember") -> {
                val m = Memory.all(ctx)
                if (m.isBlank()) "अभी मुझे कुछ याद नहीं है।" else "मुझे यह याद है: " + m.replace("\n", "। ")
            }
            has(t, "भूल जाओ", "सब भूल") -> { Memory.clear(ctx); "सब भूल गई।" }

            // ---- अभिवादन ----
            t.length < 30 && toks.any { it in setOf("hi", "hello", "hey", "नमस्ते", "हैलो", "हेलो", "हाय", "जया", "जोया", "ज़ोया", "zoya") } ->
                "नमस्ते! बताइए, मैं क्या करूँ?"

            // ---- कॉपी ----
            has(t, "कॉपी", "copy") -> {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("zoya", lastReply))
                "कॉपी कर लिया, अब कहीं भी पेस्ट कर सकते हैं।"
            }

            // ---- अलार्म और टाइमर ----
            has(t, "अलार्म", "alarm") -> {
                var h = numBefore(t, "बजे")
                if (h == null) "कितने बजे का अलार्म लगाऊँ? जैसे: सुबह छह बजे का अलार्म लगाओ।"
                else {
                    if (has(t, "शाम", "रात", "दोपहर", "pm") && h < 12) h += 12
                    val m = numBefore(t, "मिनट") ?: 0
                    go(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    "$h बजकर $m मिनट का अलार्म लगा दिया।"
                }
            }
            has(t, "टाइमर", "timer") -> {
                val sec = (numBefore(t, "घंटे") ?: 0) * 3600 + (numBefore(t, "मिनट") ?: 0) * 60 + (numBefore(t, "सेकंड") ?: 0)
                if (sec <= 0) "कितने समय का टाइमर लगाऊँ? जैसे: पाँच मिनट का टाइमर।"
                else {
                    go(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    "टाइमर चालू कर दिया।"
                }
            }

            // ---- सिस्टम ----
            has(t, "torch", "flashlight", "टॉर्च", "टार्च", "फ्लैश", "फ़्लैश") -> torch(ctx, !has(t, "off", "बंद"))
            has(t, "screenshot", "स्क्रीनशॉट", "स्क्रीन शॉट") ->
                if (Build.VERSION.SDK_INT >= 28) global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "स्क्रीनशॉट ले लिया।")
                else "इस फ़ोन में स्क्रीनशॉट संभव नहीं।"
            has(t, "notification", "नोटिफ") -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "नोटिफ़िकेशन खोल दिए।")
            has(t, "recent", "रीसेंट", "रिसेंट") -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, "हाल के ऐप दिखा दिए।")
            has(t, "lock", "लॉक", "लाक") ->
                if (Build.VERSION.SDK_INT >= 28) global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "फ़ोन लॉक कर दिया।")
                else "इस फ़ोन में यह संभव नहीं।"
            has(t, "आवाज़ बढ़ा", "आवाज बढ़ा", "वॉल्यूम बढ़ा", "volume up") -> { vol(ctx, true); "आवाज़ बढ़ा दी।" }
            has(t, "आवाज़ कम", "आवाज कम", "वॉल्यूम कम", "volume down") -> { vol(ctx, false); "आवाज़ कम कर दी।" }
            has(t, "ब्लूटूथ", "bluetooth") -> {
                go(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "ब्लूटूथ की सेटिंग खोल दी।"
            }
            has(t, "wifi", "वाईफाई", "वाई-फ़ाई", "वाई फाई", "वाइफाई", "data", "डाटा", "डेटा", "internet", "इंटरनेट") -> {
                go(ctx, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                "इंटरनेट पैनल खोल दिया है, वहाँ से डाटा या वाई-फ़ाई चालू-बंद कीजिए।"
            }
            has(t, "बैटरी", "battery") -> {
                val b = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                "बैटरी ${b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} प्रतिशत है।"
            }
            has(t, "तारीख", "तारीख़", "date", "आज कौन सा दिन") -> {
                val c = Calendar.getInstance()
                "आज ${c.get(Calendar.DAY_OF_MONTH)} ${months[c.get(Calendar.MONTH)]} ${c.get(Calendar.YEAR)} है।"
            }
            has(t, "time", "टाइम", "समय", "कितने बजे") -> {
                val c = Calendar.getInstance()
                var h = c.get(Calendar.HOUR); if (h == 0) h = 12
                "अभी $h बजकर ${c.get(Calendar.MINUTE)} मिनट हुए हैं।"
            }

            // ---- स्क्रीन पर काम (Accessibility) ----
            has(t, "स्क्रीन पर क्या", "स्क्रीन पढ़", "read screen") ->
                if (svc == null) noCtl else svc.readScreen().ifBlank { "स्क्रीन पर पढ़ने लायक कुछ नहीं मिला।" }
            has(t, "स्क्रॉल", "scroll", "नीचे जाओ", "ऊपर जाओ") ->
                if (svc == null) noCtl
                else if (svc.scroll(!has(t, "ऊपर", " up"))) "स्क्रॉल कर दिया।" else "यहाँ स्क्रॉल नहीं हो पाया।"
            has(t, "क्लिक", "click", "दबाओ", "टैप", " tap") -> {
                if (svc == null) noCtl else {
                    var name = strip(t, setOf("क्लिक", "click", "करो", "दबाओ", "टैप", "tap", "पर", "को", "बटन", "button", "जोया", "zoya"))
                    name = clickAliases[name] ?: name
                    if (name.isBlank()) "किस बटन पर क्लिक करूँ?"
                    else if (svc.clickByText(listOf(name))) "$name दबा दिया।" else "स्क्रीन पर $name नहीं मिला।"
                }
            }
            has(t, "टाइप", "type ") -> {
                if (svc == null) noCtl else {
                    val txt = strip(said.trim(), setOf("टाइप", "करो", "लिखो", "type", "Type", "Zoya", "जोया"))
                    if (svc.typeText(txt)) "लिख दिया।" else "लिखने की जगह नहीं मिली। पहले किसी लिखने वाले खाने पर टैप कीजिए।"
                }
            }

            // ---- कॉल, मैसेज, सर्च ----
            has(t, "whatsapp", "व्हाट्सएप", "वाट्सएप", "व्हाट्सऐप", "वाट्सऐप", "व्हाट्स ऐप") && has(t, "भेज", "मैसेज", "message", "लिख") -> whatsapp(ctx, t, svc)
            has(t, "कॉल", "call", "फोन लगा", "फ़ोन लगा", "मिलाओ") -> call(ctx, t)
            has(t, "youtube", "यूट्यूब", "यू ट्यूब") && has(t, "सर्च", "खोज", "search", "चलाओ", "गाना", "देख") -> {
                val q = strip(t, setOf("youtube", "यूट्यूब", "यू", "ट्यूब", "पर", "सर्च", "खोजो", "खोज", "search", "करो", "चलाओ", "में", "का", "की", "के", "दो", "जोया"))
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
                "यूट्यूब पर $q खोज रही हूँ।"
            }
            has(t, "सर्च", "search", "गूगल पर", "खोजो") -> {
                val q = strip(t, setOf("सर्च", "search", "करो", "गूगल", "पर", "खोजो", "में", "google", "दो", "जोया"))
                go(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                "$q खोज रही हूँ।"
            }

            // ---- नेविगेशन और ऐप ----
            has(t, "home", "होम") -> global(AccessibilityService.GLOBAL_ACTION_HOME, "होम स्क्रीन पर आ गई।")
            has(t, "back", "बैक", "पीछे", "वापस जाओ") -> global(AccessibilityService.GLOBAL_ACTION_BACK, "पीछे आ गई।")
            has(t, "खोल", "open", "ओपन", "चलाओ", "start", "launch") -> openApp(ctx, t)
            else -> null
        }
    }

    private fun vol(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        repeat(3) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                if (it == 2) AudioManager.FLAG_SHOW_UI else 0
            )
        }
    }

    private fun contactNumber(ctx: Context, name: String): String? {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return null
        c.use {
            while (it.moveToNext()) {
                val n = it.getString(0)?.lowercase() ?: continue
                if (n.contains(name) || (n.length > 2 && name.contains(n))) return it.getString(1)
            }
        }
        return null
    }

    private fun numberFor(ctx: Context, name: String): String? {
        val digits = name.filter { it.isDigit() }
        return if (digits.length >= 8) digits else contactNumber(ctx, name)
    }

    private fun call(ctx: Context, t: String): String {
        val name = strip(t, setOf("कॉल", "call", "करो", "को", "लगाओ", "फोन", "फ़ोन", "मिलाओ", "दो", "जोया", "zoya"))
        if (name.isBlank()) return "किसे कॉल करूँ? नाम या नंबर बोलिए।"
        val num = numberFor(ctx, name) ?: return "$name का नंबर नहीं मिला। संपर्क की अनुमति दीजिए, या नंबर बोलिए।"
        val granted = ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num")))
        return "$name को कॉल लगा रही हूँ।"
    }

    private fun whatsapp(ctx: Context, t: String, svc: ZoyaAccessibilityService?): String {
        val idx = t.indexOf(" को ")
        if (idx < 0) return "किसे भेजना है? जैसे: राहुल को व्हाट्सएप पर नमस्ते भेजो।"
        val name = t.substring(0, idx).trim()
        val msg = strip(t.substring(idx + 4), waWords)
        val raw = numberFor(ctx, name) ?: return "$name का नंबर नहीं मिला। संपर्क की अनुमति दीजिए, या नंबर बोलिए।"
        var d = raw.filter { it.isDigit() }
        if (d.length == 10) d = "91$d"
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$d?text=" + Uri.encode(msg)))
        try { ctx.packageManager.getPackageInfo("com.whatsapp", 0); i.setPackage("com.whatsapp") } catch (e: Exception) {}
        go(ctx, i)
        ui.postDelayed({ svc?.clickByText(listOf("Send", "भेजें")) }, 3500)
        return "$name को व्हाट्सएप संदेश भेज रही हूँ।"
    }

    private fun openApp(ctx: Context, t: String): String {
        var name = strip(t, openStop)
        if (name.isBlank()) return "कौन सा ऐप खोलना है?"
        name = aliases.entries.firstOrNull { name.contains(it.key) }?.value ?: name
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            ?: apps.firstOrNull {
                val l = it.loadLabel(pm).toString().lowercase()
                l.length > 2 && name.contains(l)
            }
        val pkg = hit?.activityInfo?.packageName
        if (pkg == null) {
            if (Regex("[a-z0-9-]+\\.[a-z]{2,}").containsMatchIn(name)) {
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://" + name.replace(" ", ""))))
                return "$name खोल रही हूँ।"
            }
            return "$name नाम का ऐप नहीं मिला।"
        }
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "यह ऐप खोल नहीं पाई।"
        go(ctx, i)
        return "${hit.loadLabel(pm)} खोल दिया।"
    }

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "इस फ़ोन में टॉर्च नहीं मिली।"
            cm.setTorchMode(id, on)
            if (on) "टॉर्च जला दी।" else "टॉर्च बंद कर दी।"
        } catch (e: Exception) {
            "टॉर्च चालू नहीं हो पाई।"
        }
    }
}
