package com.zoya.assistant

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private fun field(col: LinearLayout, label: String, hint: String, value: String, secret: Boolean): EditText {
        col.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Theme.text); setPadding(0, dp(12), 0, 0)
        })
        col.addView(TextView(this).apply { text = hint; textSize = 12f; setTextColor(Theme.dim) })
        val et = EditText(this).apply {
            setText(value)
            setTextColor(Theme.text)
            background = roundBg(Theme.card, dp(10).toFloat())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        col.addView(et, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return et
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        col.addView(TextView(this).apply { text = "सेटिंग्स"; textSize = 24f; setTextColor(Theme.text) })
        col.addView(TextView(this).apply {
            text = "अपनी मुफ़्त API keys यहाँ डालिए। वे सिर्फ़ इसी फ़ोन में रहेंगी। बातचीत के लिए कम से कम Gemini या OpenRouter की एक key चाहिए।"
            textSize = 14f; setTextColor(Theme.dim); setPadding(0, dp(8), 0, dp(8))
        })

        val fields = mutableListOf<Pair<String, EditText>>()
        for ((label, key, url) in Keys.all) {
            fields.add(key to field(col, label, "मुफ़्त key यहाँ से मिलेगी: $url", Keys.get(this, key), true))
        }
        for ((label, key, def) in Keys.options) {
            fields.add(key to field(col, label, "खाली छोड़ें तो यह चलेगा: $def", Keys.get(this, key), false))
        }

        col.addView(Button(this).apply {
            text = "सेव करें"
            setOnClickListener {
                for ((k, et) in fields) Keys.set(this@SettingsActivity, k, et.text.toString())
                Toast.makeText(this@SettingsActivity, "सेव हो गया", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(24) })

        col.addView(TextView(this).apply {
            text = "Zoya की याददाश्त"; textSize = 18f; setTextColor(Theme.text); setPadding(0, dp(28), 0, dp(4))
        })
        val mem = TextView(this).apply { textSize = 14f; setTextColor(Theme.dim) }
        fun showMem() { mem.text = Memory.all(this@SettingsActivity).ifBlank { "Zoya को अभी कुछ याद नहीं है।" } }
        showMem()
        col.addView(mem)
        col.addView(Button(this).apply {
            text = "सारी याददाश्त मिटाओ"
            setOnClickListener { Memory.clear(this@SettingsActivity); showMem() }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        col.addView(Button(this).apply {
            text = "वापस"
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })

        setContentView(ScrollView(this).apply { setBackgroundColor(Theme.bg); addView(col) })
    }
}
