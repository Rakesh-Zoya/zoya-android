package com.zoya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener as VoskListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private lateinit var power: PowerView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var model: Model? = null
    private var speechService: SpeechService? = null
    private var modelNote = "आवाज़ इंजन: तैयार हो रहा है..."
    private var phoneControl = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Theme.bg)
            setPadding(dp(20), dp(48), dp(20), dp(20))
        }
        root.addView(TextView(this).apply { text = "Zoya"; textSize = 28f; setTextColor(Theme.text) })
        status = TextView(this).apply { textSize = 13f; setTextColor(Theme.dim); gravity = Gravity.CENTER }
        root.addView(status)

        power = PowerView(this).apply {
            setActive(false)
            setOnClickListener { onPowerTap() }
        }
        root.addView(power, LinearLayout.LayoutParams(dp(140), dp(140)).apply { topMargin = dp(20) })
        root.addView(TextView(this).apply {
            text = "बोलने के लिए टैप करें"
            setTextColor(Theme.dim); textSize = 14f; gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
        })

        heard = TextView(this).apply { textSize = 15f; setTextColor(Theme.dim); gravity = Gravity.CENTER }
        reply = TextView(this).apply {
            textSize = 17f; setTextColor(Theme.text); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8)); setTextIsSelectable(true)
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(heard); addView(reply) }
        root.addView(ScrollView(this).apply { addView(box) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        input = EditText(this).apply {
            hint = "या यहाँ लिखकर आदेश दीजिए"
            setHintTextColor(Theme.dim); setTextColor(Theme.text)
            background = roundBg(Theme.card, dp(10).toFloat())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        row.addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(Button(this).apply { text = "भेजें"; setOnClickListener { sendTyped() } }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        root.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "फ़ोन कंट्रोल चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "सेटिंग्स (API keys और याददाश्त)"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        setContentView(root)

        StorageService.unpack(this, "model-hi", "model",
            { m -> model = m; modelNote = "आवाज़ इंजन: तैयार (ऑफ़लाइन)"; refreshStatus() },
            { _ -> modelNote = "आवाज़ इंजन: नहीं चला, Google वाला तरीका चलेगा"; refreshStatus() })
    }

    private fun refreshStatus() {
        status.text = (if (phoneControl) "फ़ोन कंट्रोल: चालू" else "फ़ोन कंट्रोल: बंद") + "\n" + modelNote
    }

    override fun onResume() {
        super.onResume()
        phoneControl = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?.contains(packageName) == true
        refreshStatus()
    }

    private fun sendTyped() {
        val s = input.text.toString().trim()
        if (s.isEmpty()) return
        input.setText("")
        handleSaid(s)
    }

    private fun onPowerTap() {
        if (listening) return
        val need = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        startListening()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 1 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening()
        else if (code == 1) show("बोलने के लिए माइक की अनुमति ज़रूरी है। तब तक नीचे लिखकर आदेश दे सकते हैं।")
    }

    private fun speechIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए...")
    }

    private fun show(text: String) {
        reply.text = text
        Commands.lastReply = text
        tts?.speak(text.take(300), TextToSpeech.QUEUE_FLUSH, null, "zoya")
    }

    private fun handleSaid(said: String?) {
        if (said.isNullOrBlank()) {
            reply.text = "सुन नहीं पाई, फिर से बोलिए।"
            return
        }
        heard.text = "आपने कहा: $said"
        val local = try { Commands.run(this, said) } catch (e: Exception) { "गड़बड़ी हुई: ${e.message}" }
        if (local != null) {
            show(local)
        } else {
            reply.text = "सोच रही हूँ..."
            Thread {
                val a = try { Brain.answer(applicationContext, said) } catch (e: Exception) { "जवाब नहीं मिला: ${e.message}" }
                runOnUiThread { show(a) }
            }.start()
        }
    }

    private fun fallbackDialog() {
        try {
            startActivityForResult(speechIntent(), 2)
        } catch (e: Exception) {
            reply.text = "इस फ़ोन में आवाज़ पहचानने वाला ऐप नहीं मिला। नीचे लिखकर आदेश दीजिए।"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK) {
            handleSaid(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull())
        } else if (requestCode == 2) {
            reply.text = "सुन नहीं पाई, फिर से बोलिए।"
        }
    }

    private fun startListening() {
        val m = model
        if (m == null) { startGoogle(); return }
        try {
            speechService?.stop()
            speechService?.shutdown()
            val rec = Recognizer(m, 16000.0f)
            val svc = SpeechService(rec, 16000.0f)
            speechService = svc
            listening = true
            power.setActive(true)
            heard.text = ""
            reply.text = "सुन रही हूँ..."
            svc.startListening(object : VoskListener {
                override fun onPartialResult(h: String?) {
                    val t = try { JSONObject(h ?: "{}").optString("partial") } catch (e: Exception) { "" }
                    if (t.isNotBlank()) heard.text = t
                }
                override fun onResult(h: String?) {
                    val t = try { JSONObject(h ?: "{}").optString("text") } catch (e: Exception) { "" }
                    if (t.isNotBlank()) {
                        svc.stop()
                        finishListening()
                        handleSaid(t)
                    }
                }
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) {
                    finishListening()
                    reply.text = "आवाज़ इंजन में गड़बड़ी: ${e?.message}"
                }
                override fun onTimeout() {
                    svc.stop()
                    finishListening()
                    reply.text = "कुछ सुनाई नहीं दिया, फिर से बोलिए।"
                }
            }, 10000)
        } catch (e: Exception) {
            finishListening()
            startGoogle()
        }
    }

    private fun startGoogle() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fallbackDialog()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) {
                    finishListening()
                    if (e == 6 || e == 7) reply.text = "सुन नहीं पाई, फिर से बोलिए।"
                    else fallbackDialog()
                }
                override fun onResults(r: Bundle?) {
                    finishListening()
                    handleSaid(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
                }
            })
        }
        listening = true
        power.setActive(true)
        heard.text = ""
        reply.text = "सुन रही हूँ..."
        recognizer?.startListening(speechIntent())
    }

    private fun finishListening() {
        listening = false
        power.setActive(false)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        speechService?.shutdown()
        model?.close()
        tts?.shutdown()
        super.onDestroy()
    }
}
