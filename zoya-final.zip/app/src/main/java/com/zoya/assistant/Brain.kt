package com.zoya.assistant

import android.content.Context

object Brain {
    private val history = mutableListOf<Pair<String, String>>()
    private val liveWords = listOf(
        "आज", "अभी", "ताज़ा", "ताजा", "खबर", "समाचार", "मौसम", "कीमत", "भाव", "स्कोर",
        "रिज़ल्ट", "रिजल्ट", "news", "price", "weather", "latest", "today", "score", "कौन जीता"
    )

    // इसे पीछे के थ्रेड में चलाइए
    fun answer(c: Context, said: String): String {
        if (!Net.online(c)) {
            return "इंटरनेट बंद है। बातचीत के लिए नेट चाहिए, पर फ़ोन के आदेश बिना नेट के चलते हैं।"
        }
        if (Keys.get(c, "gemini").isBlank() && Keys.get(c, "openrouter").isBlank()) {
            return "बातचीत के लिए सेटिंग्स में Gemini या OpenRouter की मुफ़्त key डालिए।"
        }
        var prompt = said
        if (liveWords.any { said.lowercase().contains(it) }) {
            var info = ""
            try { info = Net.tavily(c, said) } catch (e: Exception) {
                try { info = Net.serper(c, said) } catch (e2: Exception) {}
            }
            if (info.isNotBlank()) {
                prompt = "प्रश्न: $said\n\nइंटरनेट से मिली ताज़ा जानकारी:\n$info\nइसी के आधार पर जवाब दो।"
            }
        }
        val notes = Memory.all(c)
        val system = "तुम Zoya हो, एक दोस्ताना हिंदी AI सहायक। जवाब सरल हिंदी में और छोटे दो-तीन वाक्यों में दो, " +
            "जब तक उपयोगकर्ता लंबा कंटेंट (स्क्रिप्ट, पोस्ट, मार्केटिंग टेक्स्ट) न माँगे। " +
            "आवाज़ में पढ़ने लायक साफ़ वाक्य लिखो, बिना तारे या हैश चिह्नों के।" +
            (if (notes.isNotBlank()) "\nउपयोगकर्ता के बारे में याददाश्त:\n$notes" else "")
        val hist = history.takeLast(6)
        val ans = try {
            Net.gemini(c, system, hist, prompt)
        } catch (e1: Exception) {
            try {
                Net.openRouter(c, system, hist, prompt)
            } catch (e2: Exception) {
                return "AI से जवाब नहीं मिला: ${e1.message}"
            }
        }
        val clean = ans.replace("*", "").replace("#", "").trim()
        history.add(said to clean)
        return clean
    }
}
