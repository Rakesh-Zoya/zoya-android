package com.zoya.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Net {
    fun online(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun post(url: String, body: String, headers: Map<String, String>): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 40000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code ${text.take(150)}")
        return text
    }

    fun gemini(c: Context, system: String, history: List<Pair<String, String>>, prompt: String): String {
        val key = Keys.get(c, "gemini")
        if (key.isBlank()) throw RuntimeException("Gemini key नहीं है")
        val model = Keys.getOpt(c, "gemini_model")
        val contents = JSONArray()
        for ((u, a) in history) {
            contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", u))))
            contents.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", a))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        val r = JSONObject(
            post(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                body.toString(), mapOf("x-goog-api-key" to key)
            )
        )
        return r.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    fun openRouter(c: Context, system: String, history: List<Pair<String, String>>, prompt: String): String {
        val key = Keys.get(c, "openrouter")
        if (key.isBlank()) throw RuntimeException("OpenRouter key नहीं है")
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        for ((u, a) in history) {
            msgs.put(JSONObject().put("role", "user").put("content", u))
            msgs.put(JSONObject().put("role", "assistant").put("content", a))
        }
        msgs.put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", Keys.getOpt(c, "or_model")).put("messages", msgs)
        val r = JSONObject(
            post(
                "https://openrouter.ai/api/v1/chat/completions",
                body.toString(), mapOf("Authorization" to "Bearer $key")
            )
        )
        return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    fun tavily(c: Context, q: String): String {
        val key = Keys.get(c, "tavily")
        if (key.isBlank()) throw RuntimeException("Tavily key नहीं है")
        val body = JSONObject().put("api_key", key).put("query", q)
            .put("max_results", 3).put("include_answer", true)
        val r = JSONObject(post("https://api.tavily.com/search", body.toString(), emptyMap()))
        val sb = StringBuilder()
        val ans = r.optString("answer", "")
        if (ans.isNotBlank() && ans != "null") sb.append(ans).append("\n")
        val res = r.optJSONArray("results")
        if (res != null) for (i in 0 until res.length()) {
            val o = res.getJSONObject(i)
            sb.append("- ").append(o.optString("title")).append(": ").append(o.optString("content").take(300)).append("\n")
        }
        return sb.toString()
    }

    fun serper(c: Context, q: String): String {
        val key = Keys.get(c, "serper")
        if (key.isBlank()) throw RuntimeException("Serper key नहीं है")
        val body = JSONObject().put("q", q).put("gl", "in").put("hl", "hi")
        val r = JSONObject(post("https://google.serper.dev/search", body.toString(), mapOf("X-API-KEY" to key)))
        val sb = StringBuilder()
        val box = r.optJSONObject("answerBox")
        if (box != null) {
            val a = box.optString("answer", box.optString("snippet", ""))
            if (a.isNotBlank()) sb.append(a).append("\n")
        }
        val org = r.optJSONArray("organic")
        if (org != null) for (i in 0 until minOf(3, org.length())) {
            val o = org.getJSONObject(i)
            sb.append("- ").append(o.optString("title")).append(": ").append(o.optString("snippet")).append("\n")
        }
        return sb.toString()
    }
}
