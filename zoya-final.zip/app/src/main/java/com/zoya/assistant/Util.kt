package com.zoya.assistant

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

fun Activity.dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

fun roundBg(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
    setColor(color)
    cornerRadius = radius
}

object Keys {
    // (नाम, प्रीफ़ की, कहाँ से मुफ़्त मिलेगी)
    val all = listOf(
        Triple("Gemini API key", "gemini", "aistudio.google.com/apikey"),
        Triple("Tavily API key", "tavily", "tavily.com"),
        Triple("Serper API key", "serper", "serper.dev"),
        Triple("OpenRouter API key", "openrouter", "openrouter.ai/keys")
    )
    // (नाम, की, डिफ़ॉल्ट) — मॉडल बदल जाएँ तो यहाँ से बदल सकते हैं
    val options = listOf(
        Triple("Gemini मॉडल का नाम", "gemini_model", "gemini-2.5-flash"),
        Triple("OpenRouter मॉडल का नाम", "or_model", "meta-llama/llama-3.3-70b-instruct:free")
    )

    private fun prefs(c: Context) = c.getSharedPreferences("zoya_keys", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): String = prefs(c).getString(k, "") ?: ""
    fun set(c: Context, k: String, v: String) = prefs(c).edit().putString(k, v.trim()).apply()
    fun getOpt(c: Context, k: String): String {
        val v = get(c, k)
        return if (v.isNotBlank()) v else options.first { it.second == k }.third
    }
}

object Memory {
    private fun prefs(c: Context) = c.getSharedPreferences("zoya_mem", Context.MODE_PRIVATE)
    fun all(c: Context): String = prefs(c).getString("notes", "") ?: ""
    fun add(c: Context, note: String) {
        val cur = all(c)
        val next = if (cur.isBlank()) note.trim() else cur + "\n" + note.trim()
        prefs(c).edit().putString("notes", next.takeLast(2000)).apply()
    }
    fun clear(c: Context) = prefs(c).edit().remove("notes").apply()
}

object Theme {
    val bg = Color.parseColor("#0A0A0F")
    val card = Color.parseColor("#1A1A20")
    val text = Color.parseColor("#F2F2F5")
    val dim = Color.parseColor("#8A8A95")
    val accent = Color.parseColor("#E5484D")
}
