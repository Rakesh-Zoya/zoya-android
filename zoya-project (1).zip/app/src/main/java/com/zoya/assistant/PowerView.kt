package com.zoya.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.View

class PowerView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
    }
    private val bg = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Theme.card)
    }

    init { background = bg }

    fun setActive(active: Boolean) {
        val d = resources.displayMetrics.density
        bg.setStroke((3 * d).toInt(), if (active) Color.parseColor("#4CAF50") else Theme.accent)
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        val r = w * 0.2f
        p.strokeWidth = w * 0.045f
        cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -60f, 300f, false, p)
        cv.drawLine(cx, cy - r * 1.15f, cx, cy - r * 0.1f, p)
    }
}
