package com.zoya.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.provider.Settings
import java.util.Calendar

object Commands {
    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "यूटयूब" to "youtube",
        "व्हाट्सऐप" to "whatsapp", "व्हाट्सएप" to "whatsapp", "वाट्सएप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "क्रोम" to "chrome", "कैमरा" to "camera", "सेटिंग" to "settings",
        "गैलरी" to "gallery", "फेसबुक" to "facebook", "इंस्टाग्राम" to "instagram",
        "फोन" to "phone", "फ़ोन" to "phone", "मैप्स" to "maps", "जीमेल" to "gmail",
        "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "मैसेज" to "messages"
    )
    private val stop = setOf(
        "खोलो", "खोल", "दो", "करो", "को", "open", "start", "launch", "please",
        "जोया", "ज़ोया", "zoya", "चलाओ", "ऐप", "app", "में", "जाओ"
    )

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }

    fun run(ctx: Context, said: String): String {
        val t = said.lowercase().trim()
        val svc = ZoyaAccessibilityService.instance

        fun global(action: Int, ok: String): String =
            if (svc == null) "फ़ोन कंट्रोल चालू नहीं है। पहले उसे चालू कीजिए।"
            else { svc.performGlobalAction(action); ok }

        return when {
            has(t, "torch", "flashlight", "टॉर्च", "फ्लैशलाइट") ->
                torch(ctx, !has(t, "off", "बंद"))
            has(t, "screenshot", "स्क्रीनशॉट") ->
                if (Build.VERSION.SDK_INT >= 28) global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "स्क्रीनशॉट ले लिया।")
                else "इस फ़ोन में स्क्रीनशॉट संभव नहीं।"
            has(t, "notification", "नोटिफ") ->
                global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "नोटिफ़िकेशन खोल दिए।")
            has(t, "recent", "रीसेंट") ->
                global(AccessibilityService.GLOBAL_ACTION_RECENTS, "हाल के ऐप दिखा दिए।")
            has(t, "lock", "लॉक") ->
                if (Build.VERSION.SDK_INT >= 28) global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "फ़ोन लॉक कर दिया।")
                else "इस फ़ोन में यह संभव नहीं।"
            has(t, "wifi", "वाईफाई", "वाई-फ़ाई", "वाई फाई", "data", "डाटा", "डेटा", "internet", "इंटरनेट") -> {
                val i = Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                "इंटरनेट पैनल खोल दिया है, वहाँ से डाटा या वाई-फ़ाई चालू-बंद कीजिए।"
            }
            has(t, "time", "टाइम", "समय", "बजे") -> {
                val c = Calendar.getInstance()
                var h = c.get(Calendar.HOUR)
                if (h == 0) h = 12
                "अभी $h बजकर ${c.get(Calendar.MINUTE)} मिनट हुए हैं।"
            }
            has(t, "home", "होम") ->
                global(AccessibilityService.GLOBAL_ACTION_HOME, "होम स्क्रीन पर आ गई।")
            has(t, "back", "पीछे", "वापस जाओ") ->
                global(AccessibilityService.GLOBAL_ACTION_BACK, "पीछे आ गई।")
            has(t, "खोल", "open", "चलाओ", "start", "launch") -> openApp(ctx, t)
            else -> "माफ़ कीजिए, यह आदेश अभी मुझे नहीं आता।"
        }
    }

    private fun openApp(ctx: Context, t: String): String {
        var name = t.split(" ").filter { it.isNotBlank() && it !in stop }.joinToString(" ")
        if (name.isBlank()) return "कौन सा ऐप खोलना है?"
        name = aliases.entries.firstOrNull { name.contains(it.key) }?.value ?: name
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            ?: apps.firstOrNull {
                val l = it.loadLabel(pm).toString().lowercase()
                l.length > 2 && name.contains(l)
            }
        val pkg = hit?.activityInfo?.packageName ?: return "$name नाम का ऐप नहीं मिला।"
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "यह ऐप खोल नहीं पाई।"
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "${hit.loadLabel(pm)} खोल दिया।"
    }

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "इस फ़ोन में टॉर्च नहीं मिली।"
            cm.setTorchMode(id, on)
            if (on) "टॉर्च जला दी।" else "टॉर्च बंद कर दी।"
        } catch (e: Exception) {
            "टॉर्च चालू नहीं हो पाई।"
        }
    }
}
