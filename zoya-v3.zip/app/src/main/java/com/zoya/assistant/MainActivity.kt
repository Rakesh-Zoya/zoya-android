package com.zoya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private lateinit var power: PowerView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Theme.bg)
            setPadding(dp(24), dp(64), dp(24), dp(32))
        }
        root.addView(TextView(this).apply {
            text = "Zoya"; textSize = 28f; setTextColor(Theme.text)
        })
        status = TextView(this).apply { textSize = 14f; setTextColor(Theme.dim) }
        root.addView(status)

        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        power = PowerView(this).apply {
            setActive(false)
            setOnClickListener { onPowerTap() }
        }
        root.addView(power, LinearLayout.LayoutParams(dp(160), dp(160)))
        root.addView(TextView(this).apply {
            text = "Zoya से बात करने के लिए टैप करें"
            setTextColor(Theme.dim); textSize = 15f; gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        })
        heard = TextView(this).apply {
            textSize = 16f; setTextColor(Theme.dim); gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        reply = TextView(this).apply {
            textSize = 18f; setTextColor(Theme.text); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(heard)
        root.addView(reply)

        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        root.addView(Button(this).apply {
            text = "फ़ोन कंट्रोल चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "सेटिंग्स (API keys)"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?.contains(packageName) == true
        status.text = if (enabled) "फ़ोन कंट्रोल: चालू" else "फ़ोन कंट्रोल: बंद"
    }

    private fun onPowerTap() {
        if (listening) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        startListening()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 1 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) startListening()
        else reply.text = "बोलने के लिए माइक की अनुमति ज़रूरी है।"
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply.text = "इस फ़ोन में आवाज़ पहचानने की सुविधा नहीं मिली।"
            return
        }
        recognizer?.destroy()
        val googlePkg = "com.google.android.googlequicksearchbox"
        val hasGoogle = try { packageManager.getPackageInfo(googlePkg, 0); true } catch (e: Exception) { false }
        val rec = if (hasGoogle) SpeechRecognizer.createSpeechRecognizer(
            this,
            android.content.ComponentName(googlePkg, "com.google.android.voicesearch.serviceapi.GoogleRecognitionService")
        ) else SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec.apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) {
                    finishListening()
                    reply.text = "सुन नहीं पाई (कोड $e), फिर से बोलिए।"
                }
                override fun onResults(r: Bundle?) {
                    finishListening()
                    val said = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (said.isNullOrBlank()) {
                        reply.text = "सुन नहीं पाई, फिर से बोलिए।"
                        return
                    }
                    heard.text = "आपने कहा: $said"
                    val ans = Commands.run(this@MainActivity, said)
                    reply.text = ans
                    tts?.speak(ans, TextToSpeech.QUEUE_FLUSH, null, "zoya")
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        listening = true
        power.setActive(true)
        heard.text = ""
        reply.text = "सुन रही हूँ..."
        recognizer?.startListening(i)
    }

    private fun finishListening() {
        listening = false
        power.setActive(false)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
