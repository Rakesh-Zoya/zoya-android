package com.zoya.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Theme.bg)
            setPadding(dp(24), dp(64), dp(24), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "Zoya"; textSize = 28f; setTextColor(Theme.text)
        })
        status = TextView(this).apply { textSize = 14f; setTextColor(Theme.dim) }
        root.addView(status)

        val spacer1 = android.view.View(this)
        root.addView(spacer1, LinearLayout.LayoutParams(1, 0, 1f))

        val circle = TextView(this).apply {
            text = "⏻"; textSize = 56f; gravity = Gravity.CENTER
            setTextColor(Theme.text)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Theme.card)
                setStroke(dp(3), Theme.accent)
            }
            setOnClickListener {
                Toast.makeText(this@MainActivity, "आवाज़ अगले वर्ज़न में जुड़ेगी", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(circle, LinearLayout.LayoutParams(dp(160), dp(160)))
        root.addView(TextView(this).apply {
            text = "Zoya से बात करने के लिए टैप करें"
            setTextColor(Theme.dim); textSize = 15f; gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        })

        val spacer2 = android.view.View(this)
        root.addView(spacer2, LinearLayout.LayoutParams(1, 0, 1f))

        root.addView(Button(this).apply {
            text = "फ़ोन कंट्रोल चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "सेटिंग्स (API keys)"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?.contains(packageName) == true
        status.text = if (enabled) "फ़ोन कंट्रोल: चालू" else "फ़ोन कंट्रोल: बंद"
    }
}
