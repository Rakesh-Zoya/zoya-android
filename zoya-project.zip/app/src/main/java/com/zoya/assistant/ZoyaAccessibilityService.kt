package com.zoya.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ZoyaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // अगले वर्ज़न में: स्क्रीन पढ़ना, टैप और टाइप यहीं से होगा
    }

    override fun onInterrupt() {}
}
